import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe from csv
df=pd.read_csv("boxplot.csv", header=None, names=['col1', 'col2','col3'])
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
plotMap.append(df['col1'].dropna().tolist())
plotMap.append(df['col2'].dropna().tolist())
plotMap.append(df['col3'].dropna().tolist())

#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2,3],["Jhajjar","Jind","Gurgaon"])
plt.xlabel("Districts in Haryana")
plt.ylabel("Population")


plt.legend()
plt.show()