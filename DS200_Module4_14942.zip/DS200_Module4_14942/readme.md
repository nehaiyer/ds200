# ds200
DS 200 Module 4

The plots are created using the dataset "Trend in population of Towns : Haryana".
Link to dataset: https://data.gov.in/resources/trend-population-towns-haryana.

Observations:

1. Bar plot:
   Data file: barplot.csv
   
   The bar plot shows the population trend in Faridabad district of Haryana from 2011 to 1901.
   Individual bars indicate the population as per captured in years 2011, 2001, 1981, 1971, 1951 and 1901.
   The population shows a steep increasing trend from 1901 to 2011.
   
2. Scatter plot:
   Data file: scatterplot.csv
   
   The scatter plot shows a correlation between the population of two districts Hisar and Karnal of Haryana.
   As observed from the plot, the population trend for both districts is closely related from 1901 to 2011. The data points closely follows y=x curve. 
   
3. Box plot:
   Data file: boxplot.csv
   
   The box plot shows the population distribution for three districts Jhajjar, Jind and Gurgaon of Haryana.
   As observed from the plots, the minimum population value is quite similar for all the districts. However the population distribution for Gurgaon is concentrated as compared to Jhajjar and Jind districts. 
   There are no outliers observed in the population distribution.