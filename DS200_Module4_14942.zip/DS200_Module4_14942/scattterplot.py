import pandas as pd
import matplotlib.pyplot as plt
import sys
#create dataframe
df=pd.read_csv("scatterplot.csv", header=None, names=['col1', 'col2'])

#plot scatter with first column as x values and second column as y values
plt.scatter(df['col1'],df['col2'],color='#dd12dd',label="Population correlation between districts")

#specifying labels
plt.xlabel("Population in Hisar district")
plt.ylabel("Population in Karnal district")

#enable legend
plt.legend()
plt.show()